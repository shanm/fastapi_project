# Pytest test suite mirroring the app structure
